# Putting grid to use - part 2

