# Putting grid to use - part 1

