# The loose ends

